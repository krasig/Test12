@javax.xml.bind.annotation.XmlSchema(namespace = "http://iisda.government.bg/RAS/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package delme;
